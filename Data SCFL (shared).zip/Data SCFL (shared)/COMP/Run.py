"""
The data for COMP instances
Contains: I,J,K,R (note that set J is the same as set K)
          buying power d
          attractiveness matrix a and b
          distance matrix l
"""
import numpy as np

I = 100            # number of customer zones
J = 100            # number of leader facilities
K = 100            # number of follower facilities
R = 1              # number of design options
####################################################
file1 = open("Code 1011(w).txt", "r")  # read the txt file. This example reads the 1001(w) data.
Lines = file1.readlines() 
d = np.zeros(100)
x_axis = np.zeros(100)
y_axis = np.zeros(100)
Length = len(Lines)
for i in range(Length):
    x_axis[i] = float(((Lines[i].strip()).split())[1])
    y_axis[i] = float(((Lines[i].strip()).split())[2])    
    d[i] = float(((Lines[i].strip()).split())[3])
l = np.zeros((100,100))
for i in range(100):
    for j in range(100):
        l[i,j] = np.sqrt(np.square(x_axis[i] - x_axis[j]) + np.square(y_axis[i] - y_axis[j]))/100 # distance measured in 100 meter
np.random.seed(0)
a = np.random.uniform(1,5,(I,1))
b = np.random.uniform(1,5,(I,1))