"""
The data for RND instances

Input:  I,J,K,R
Output:   utility matrix u, v
          buying power d
          cost matrix c and g
"""
import numpy as np
import matplotlib.pyplot as plt

def GenerateRNDData(I,J,K,R):    
    Cus_location = []
    Leader_location = []
    Follower_location = []
    np.random.seed(0)
    d = np.random.randint(100,200,I)        
    np.random.seed(2)        
    Location_Cus_x = np.random.uniform(0,10,I)

    np.random.seed(3)        
    Location_Cus_y = np.random.uniform(0,10,I)

    np.random.seed(4)        
    Location_Leader_x = np.random.uniform(0,10,J)

    np.random.seed(5)        
    Location_Leader_y = np.random.uniform(0,10,J)    

    np.random.seed(6)        
    Location_Follower_x = np.random.uniform(0,10,K)

    np.random.seed(7)        
    Location_Follower_y = np.random.uniform(0,10,K)  
  
    for i in range(I):
        Cus_location.append((Location_Cus_x[i],Location_Cus_y[i]))          
    for j in range(J):
        Leader_location.append((Location_Leader_x[j], Location_Leader_y[j]))  
    for k in range(K):
        Follower_location.append((Location_Follower_x[k], Location_Follower_y[k]))         
    plt.scatter(Location_Cus_x, Location_Cus_y, marker='^')
    plt.scatter(Location_Leader_x, Location_Leader_y, marker = 'o', color = 'b')
    plt.scatter(Location_Follower_x, Location_Follower_y, marker = 's', color = 'r')
    plt.show()      

    #### compute the distance matrix. LC: distance between leader facilities and customers; FC: distances between follower facilities and customers
    LC = []
    for i in range(len(Cus_location)):
        l = []
        for j in range(len(Leader_location)):
            dis = np.sqrt(np.sum([np.square(Cus_location[i][0] - Leader_location[j][0]), np.square(Cus_location[i][1] - Leader_location[j][1])]))
            l.append(dis)
        LC.append(l)        
    FC = []
    for i in range(len(Cus_location)):
        l = []
        for k in range(len(Follower_location)):
            dis = np.sqrt(np.sum([np.square(Cus_location[i][0] - Follower_location[k][0]), np.square(Cus_location[i][1] - Follower_location[k][1])]))
            l.append(dis)
        FC.append(l)
    LC, FC = np.array(LC), np.array(FC)    
    #### compute gravity utility
    a = np.array([1,2,3,4,5])
    b = np.array([1,2,3,4,5])
    u = np.zeros((I,J,R))      #### the utility of the candidate facilities
    v = np.zeros((I,K,R))     ##### the utility of competitor's facilities
    for r in range(R):
        u[:,:,r] = a[r]/(LC+1)**2
        v[:,:,r] = b[r]/(FC+1)**2       
    #### generate facility cost          
    c = np.zeros((J,R))     # cost of leader facilities         
    g = np.zeros((K,R))     # cost of follower facilities 
    np.random.seed(100)
    for r in range(R):
        c[:,r] = np.random.uniform(0.7,0.9,J)*(r+1) + 0.2
    for r in range(R):
        g[:,r] = np.random.uniform(0.7,0.9,K)*(r+1) + 0.2
    return u, v, d, c, g

if __name__ == "__main__":
    ### for example
    I = 100            # number of customer zones
    J = 100            # number of leader facilities
    K = 100            # number of follower facilities
    R = 3
    u,v,d,c,g = GenerateRNDData(I, J, K, R)



