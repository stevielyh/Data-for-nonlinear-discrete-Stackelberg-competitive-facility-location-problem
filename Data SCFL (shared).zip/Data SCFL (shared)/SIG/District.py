# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 22:47:31 2019

@author: isehd
"""
import numpy as np
import csv
from itertools import zip_longest
from Data import readData
csv.register_dialect('myDialect',
delimiter = ',',
quoting=csv.QUOTE_ALL,
skipinitialspace=True)


#filename = '1PostCodeLocker.csv'
#filename = '2PWcode.csv'
#filename = '3ResidentalPostCode.csv'
#with open(filename, mode = 'r') as csv_file:
#    csv_reader = csv.reader(csv_file, dialect='myDialect')
#    line_count = 0
#    j = []
#    for row in csv_reader:
#        if line_count==0:
#            line_count += 1
#        else:
#            if len(row[0]) != 6:
##                line_count += 1
#                d = '0' + row[0]
#                print(f'Row {line_count} postcode is {len(row[0])} and now is {d}')
##                d = '0' + row[0]
#                j.append(d)
#                line_count += 1
#            else:
#                line_count += 1
#                j.append(row[0])

def District(filename):
    with open(filename, mode = 'r') as csv_file:
        csv_reader = csv.reader(csv_file, dialect='myDialect')
        line_count = 0
        i = {}
        m = {}
        j = []
        k = []
        n = []
        for row in csv_reader:
            if line_count == 0:
                print(f'This is the title row')
                line_count += 1
            else:
#                s = row[1].split(',')
                result = [x.strip() for x in row[1].split(',')]
                j.append(result)
                i[row[2]] = row[0].strip()
                n.append(row[0].strip())
                k.append(row[2])
                m[row[2]] = (row[0].strip(),[x.strip() for x in row[1].split(',')])
#        return i,j,m
        return j,n,k
    
#q,p,h = District('SingaporeDistrictCOde.csv')
#q1, p1, h1 = District('SingaporeDistrictCOde.csv')

def DistrictDivided(filename):
    # get the postcode of the "filename" and assign them to list j
    with open(filename, mode = 'r') as csv_file:
        csv_reader = csv.reader(csv_file, dialect='myDialect')
        line_count = 0
        j = []
        for row in csv_reader:
            if line_count==0:
                line_count += 1
            else:
                if len(row[0]) != 6:
                    line_count += 1
                    d = '0' + row[0]
#                    print(f'Row {line_count} postcode is {len(row[0])} and now is {d}')
                    j.append(d)
                    line_count += 1
                else:
                    j.append(row[0])
                    line_count += 1
        # after we get the total postcode of the filename in list j
        # we need to judge whether the first two characters of the element in j belong to which districe  
#    print(len(j))
    k1 = []
    k2 = []
    q1, p1, h1 = District('SingaporeDistrictCOde.csv')
    for x in range(len(j)):
        for y in range(len(q1)):
            if j[x][0:2] in q1[y]:
                s = [p1[y],j[x]]
                k1.append(s)
                k2.append(p1[y])
#            else:
#                print(f'The postcode {j[x]} has no district and line {x} and line {y}')             
    return j, k1, k2
#str = '2PWcode.csv'
#str = '1PostCodeLocker.csv'
#str = '3ResidentalPostCode.csv'
#f, f1, f2 = DistrictDivided(str)

#str2 = '2PWcodeNumbers.csv'
#str2 = '1PostCodeLockerNumbers.csv'
#str2 = '3ResidentalPostCodeNumbers.csv'
def writeValue(filename, value1, value2):
    d = [value1,value2]
    export_data = zip_longest(*d, fillvalue = '')
    with open(filename, 'w', encoding="ISO-8859-1", newline='') as myfile:
        wr = csv.writer(myfile)
        wr.writerow(("District Nubmer", "Post code of location"))
#        for v in export_data:
#            wr.writerows(v)
        wr.writerows(export_data)
    myfile.close()
    print("The value have written into the csv file")
#d = writeValue(str2, f2,f)
        
def sg_region(filename, v):
    with open(filename, mode = 'r') as csv_file:
        csv_reader = csv.reader(csv_file, dialect='myDialect')
#        line_count = 0
        j = []
        k = []
        for row in csv_reader:
            j.append(row)
    for i in range(len(v)):
        for x in range(len(j)):
            if v[i][1][0] == '0':
                if v[i][1][1] in j[x]:
                    k.append(j[x][0])
            else:
                if v[i][1][:2] in j[x]:
                    k.append(j[x][0])
#            if v[i][1][:2] in j[x]:
#                k.append(j[x][0])
    print(f'The length of k is {len(k)}.')
    return j,k
    
filename1 = 'RegionSg.csv'

#a,b  = sg_region(filename1,f1) 

#str3 = '3ResionDistrictMapping.csv'
#str3 = '2PostDistrictMapping.csv'
#str3 = '1LockerDistrictMapping.csv'
#d1 =  writeValue(str3,b,f)
####This function is used to return the residentalfile index and locker location index
### which belong to the region         
def region_distance(region,filenameResidental, filename2):
    with open(filenameResidental, mode = 'r') as csv_file:
        csv_reader = csv.reader(csv_file, dialect='myDialect')
        j = []
        for row in csv_reader:
            j.append(row)
    with open(filename2, mode = 'r') as csv_file2:
        csv_reader2 = csv.reader(csv_file2, dialect='myDialect')
        k = []
        for row in csv_reader2:
            k.append(row)
    del j[0]
    del k[0]
#    print(j[21][0])
#    line = 0
    m = []
    n = []
    # when the element in J[x][0] equatal to region "A" or "B", insert the index into the list.
    for x in range(len(j)):
        if region == j[x][0]:
            m.append(x)
    for y in range(len(k)):
        if region == k[y][0]:
            n.append(y)
    return m,n
# return the filenameResidental index and the filename 2 index in the region
#c1,c2 = region_distance('A','3ResionDistrictMapping.csv','1LockerDistrictMapping.csv')
    
#####################################################
str1 = 'ResidentDistanceToLockers.csv'
str2 = 'ResidentdistancetoPOP.csv'
str3 = 'ResidentalDemand.csv'

d = readData(str3)         # demand   I = 272, J = 139, k = 137
I, J, L = readData(str1)   # L: distance between zones and lockers            
K, l = readData(str2)      # l: distance between zones and po_stations      
#####################################################
# This function is used to obtain the demand, L and l from d, L and l according to C1, C2, D1, D2.
        
def Last_Result(region, demand, L, l):
    #region is one of 'A', 'B', 'C', 'D', 'E'
    # demand is the residential demand
    # I is the residental nodes
    # L: distance between zones and lockers
    # l: distance between zones and po_stations
    C1, C2 = region_distance(region,'3ResionDistrictMapping.csv','1LockerDistrictMapping.csv')
    D1, D2 = region_distance(region,'3ResionDistrictMapping.csv','2PostDistrictMapping.csv')
    de = []
    dis1 = []
    dis2 = []
    d_lock = []
    d_pos = []
    for x in C1:
        de.append(demand[x])
        # select the row index (in other words the residental location index.)
        dis1.append(l[x])
        dis2.append(L[x])
     # select the column index (in other words the locker index.)  
    for row1 in dis2:
        g = []
        for y in C2:
            g.append(row1[y])
        d_lock.append(g)
#    for y in C2:
#        g = []
#        for row1 in dis2:
#            d_lock.append(row1[y])
##            print(len(d_lock))
    # select the column index (in other words the popstation index.)
    for row2 in dis1:
        g1 = []
        for z in D2:
            g1.append(row2[z])
        d_pos.append(g1)
#    for z in D2:
#        for row2 in dis1:
#            d_pos.append(row2[z])
#            print(len(d_pos))
#    return de, d_lock, d_pos, dis1, dis2
#    return de, d_lock, d_pos, dis1, dis2
    return np.array(de), np.array(d_lock), np.array(d_pos)    



   
#region = 'D'
##d1, L1, l1, dis1, dis2= Last_Result(region, d,L, l)
#d1, L1, l1= Last_Result(region, d,L, l)