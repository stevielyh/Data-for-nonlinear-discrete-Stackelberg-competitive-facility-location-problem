# -*- coding: utf-8 -*-
"""
Created on Sat Jul 27 12:19:38 2019

@author: isehd
"""
# Read the data files e.g., 'ResidentDistanceToLockers.csv'
# and return the residental nodes I, locker candidates M, the distance from redisental node to locker candidates. 
import csv

csv.register_dialect('myDialect',
delimiter = ',',
quoting=csv.QUOTE_ALL,
skipinitialspace=True)

def readData(filename):
    with open (filename, mode = 'r') as csv_file:
        csv_reader = csv.reader(csv_file, dialect='myDialect')
        line_count = 0
        d_rs = []
        for row in csv_reader:
            if line_count == 0:
                #print(f'Column names are {", ".join(row)}')
                # read the first line which is the name of locker location and assign it to "row_name" 
                row_name = row
                #print(len(row_name) - 1) # This is the total candidate locker location numbers
                number_node = len(row_name) - 1
                line_count += 1
            else:
                #print(f'This is me')
                row = [int(i) for i in row[1:]]
                d_rs.append(row)
                #print(d_rs)
                line_count += 1
        number_residental = line_count - 1
        if filename == 'ResidentDistanceToLockers.csv':
            return number_residental, number_node, d_rs
        elif filename == 'ResidentdistancetoPOP.csv':
            return number_node, d_rs
        else:
            return d_rs
str = 'ResidentDistanceToLockers.csv'
str1 = 'ResidentdistancetoPOP.csv'
M, D_rs = readData(str1)
#print(f'The residential node is {I}.')
#print(f'The candidate locker node is {M}.')
#print(D_rs[0][0])
str2 = 'ResidentalDemand.csv'
d_i = readData(str2)

