"""
The data for SIG instances.

Contains: I,J,K
          distance matirx L and l
          buying power d (normalized)
"""
import numpy as np
from Data import readData

str1, str2, str3 = 'ResidentDistanceToLockers.csv', 'ResidentdistancetoPOP.csv', 'ResidentalDemand.csv'
d = readData(str3)          # demand (buying power) 
                            # I = 272, J = 139, K = 137, R = 1 
I, J, L = readData(str1)    # L: distance between customer zones and leader facilities measured in meter       
K, l = readData(str2)       # l: distance between customer zones and follower facilities  measured in meter
L, l = np.array(L)/1000, np.array(l)/1000   # the final distance matrix (np array) is measured in kilometer
d = np.reshape(np.array(d),(I,))/np.sum(d)  # demand is normalized